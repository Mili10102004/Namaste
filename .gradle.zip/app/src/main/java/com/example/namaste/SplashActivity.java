package com.example.namaste;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    private View screen1, screen2;
    private Button btnNext1, btnNext2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen1);

        // Initialize views
        screen1 = findViewById(R.id.screen1);
        screen2 = findViewById(R.id.screen2);
        btnNext1 = findViewById(R.id.btnNext1);
        btnNext2 = findViewById(R.id.btnNext2);

        // Button click to switch to Screen 2
        btnNext1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                screen1.setVisibility(View.GONE); // Hide Screen 1
                screen2.setVisibility(View.VISIBLE); // Show Screen 2
            }
        });

        // Button click to navigate to the next activity
        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the next activity (e.g., Login or Home screen)
                Intent intent = new Intent(SplashActivity.this, SignupActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
