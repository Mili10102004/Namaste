package com.example.namaste;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SearchView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class HelpSupportActivity extends AppCompatActivity {

    private ListView faqListView;
    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_support);

        faqListView = findViewById(R.id.faqListView);
        searchView = findViewById(R.id.searchView);

        // Initialize FAQ list
        faqList = new ArrayList<>();
        faqList.add(new QuestionAnswer("What is Namaste Now?", "Namaste Now is an app to send homemade food and items from India to students and professionals abroad."));
        faqList.add(new QuestionAnswer("How do I track my shipment?", "You can track your shipment in real-time through the tracking feature in the app."));
        faqList.add(new QuestionAnswer("What couriers do you work with?", "We work with multiple couriers to ensure safe and timely delivery of your items."));
        faqList.add(new QuestionAnswer("Is there a delivery fee?", "Yes, there is a delivery fee depending on the weight, size, and destination of the shipment."));

        // Set up adapter for ListView
        adapter = new HelpAndSupportAdapter(this, faqList);
        faqListView.setAdapter(adapter);

        // Search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterFAQs(newText);
                return false;
            }
        });
    }

    // Filter FAQs based on search query
    private void filterFAQs(String query) {
        List<QuestionAnswer> filteredList = new ArrayList<>();
        for (QuestionAnswer qa : faqList) {
            if (qa.getQuestion().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(qa);
            }
        }
        adapter = new HelpAndSupportAdapter(this, filteredList);
        faqListView.setAdapter(adapter);
    }
}
